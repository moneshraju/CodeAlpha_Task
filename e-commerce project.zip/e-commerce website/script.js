// ===== Toggle Mobile Navigation =====
const bar = document.getElementById('bar');
const nav = document.getElementById('navbar');
const close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
    });
}

// ===== Close Navbar on Link Click (Mobile) =====
const navLinks = document.querySelectorAll('#navbar li a');
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        nav.classList.remove('active');
    });
});

// ===== Cart Icon Click Alert =====
const cartButtons = document.querySelectorAll('.cart');
cartButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        alert('Product added to cart!');
        // You can replace this with actual cart logic later.
    });
});

// ===== Newsletter Form Validation (Optional) =====
const newsletterForm = document.querySelector('#newsletter .form');
const newsletterInput = newsletterForm.querySelector('input');
const newsletterButton = newsletterForm.querySelector('button');

newsletterButton.addEventListener('click', () => {
    const email = newsletterInput.value.trim();
    if (!email || !email.includes('@')) {
        alert("Please enter a valid email address.");
    } else {
        alert(`Thanks for signing up, ${email}!`);
        newsletterInput.value = '';
    }
});
