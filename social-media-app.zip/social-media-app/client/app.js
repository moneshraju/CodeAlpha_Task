const API_URL = 'http://localhost:5000/api';
let token = localStorage.getItem('token');
let currentUser = null;

async function login() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const res = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (data.token) {
    token = data.token;
    localStorage.setItem('token', token);
    currentUser = data.user;
    updateUI();
  } else {
    alert(data.msg);
  }
}

async function register() {
  const username = document.getElementById('register-username').value;
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  const res = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password }),
  });
  const data = await res.json();
  if (data.token) {
    token = data.token;
    localStorage.setItem('token', token);
    currentUser = data.user;
    updateUI();
  } else {
    alert(data.msg);
  }
}

function logout() {
  token = null;
  localStorage.removeItem('token');
  currentUser = null;
  updateUI();
}

async function createPost() {
  const content = document.getElementById('post-content').value;
  const res = await fetch(`${API_URL}/posts`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ content }),
  });
  if (res.ok) {
    document.getElementById('post-content').value = '';
    fetchPosts();
  }
}

async function fetchPosts() {
  const res = await fetch(`${API_URL}/posts`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  const posts = await res.json();
  const postList = document.getElementById('post-list');
  postList.innerHTML = posts.map(post => `
    <div>
      <p>${post.content}</p>
      <small>By ${post.author.username} on ${new Date(post.createdAt).toLocaleString()}</small>
      <button onclick="likePost('${post._id}')">${post.likes.includes(currentUser.id) ? 'Unlike' : 'Like'} (${post.likes.length})</button>
      <button onclick="followUser('${post.author._id}')">${currentUser.following?.includes(post.author._id) ? 'Unfollow' : 'Follow'}</button>
      <div>
        <input type="text" id="comment-${post._id}" placeholder="Add a comment">
        <button onclick="addComment('${post._id}')">Comment</button>
      </div>
      <div id="comments-${post._id}"></div>
    </div>
  `).join('');
  posts.forEach(post => fetchComments(post._id));
}

async function likePost(postId) {
  await fetch(`${API_URL}/posts/${postId}/like`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
  });
  fetchPosts();
}

async function followUser(userId) {
  await fetch(`${API_URL}/users/${userId}/follow`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
  });
  // Refresh user data to update following list
  const res = await fetch(`${API_URL}/users/me`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  currentUser = await res.json();
  fetchPosts();
}

async function addComment(postId) {
  const content = document.getElementById(`comment-${postId}`).value;
  await fetch(`${API_URL}/comments/${postId}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ content }),
  });
  document.getElementById(`comment-${postId}`).value = '';
  fetchComments(postId);
}

async function fetchComments(postId) {
  const res = await fetch(`${API_URL}/comments/${postId}`, {
    headers: { 'Authorization': `Bearer ${token}` },
  });
  const comments = await res.json();
  const commentList = document.getElementById(`comments-${postId}`);
  commentList.innerHTML = comments.map(comment => `
    <p>${comment.content} <small>by ${comment.author.username}</small></p>
  `).join('');
}

function updateUI() {
  const authDiv = document.getElementById('auth');
  const profileDiv = document.getElementById('profile');
  if (token && currentUser) {
    authDiv.style.display = 'none';
    profileDiv.style.display = 'block';
    document.getElementById('profile-info').innerText = `Welcome, ${currentUser.username}`;
    fetchPosts();
  } else {
    authDiv.style.display = 'block';
    profileDiv.style.display = 'none';
    document.getElementById('post-list').innerHTML = '';
  }
}

// Initial UI update
updateUI();