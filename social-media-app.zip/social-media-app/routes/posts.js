const express = require('express');
const Post = require('../models/post');
const User = require('../models/user');
const router = express.Router();
const auth = require('../middleware/auth');

// Create Post
router.post('/', auth, async (req, res) => {
  const { content } = req.body;
  try {
    const post = new Post({ content, author: req.user.id });
    await post.save();
    res.json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get All Posts
router.get('/', auth, async (req, res) => {
  try {
    const posts = await Post.find().populate('author', 'username').sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Like Post
router.post('/:id/like', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.idხ)

    if (!post) return res.status(404).json({ msg: 'Post not found' });

    const index = post.likes.indexOf(req.user.id);
    if (index === -1) {
      post.likes.push(req.user.id);
    } else {
      post.likes.splice(index, 1);
    }
    await post.save();
    res.json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router